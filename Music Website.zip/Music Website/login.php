<?php

session_start();

include('connection.php');
$msg = false ;
if (isset($_POST['user_name'])) {
    $user_name = $_POST['user_name'];
    $user_password = $_POST['user_password'];

    $query  =  "select * from users where name = '".$user_name."' AND password = '".$user_password."' limit 1";

    $result = mysqli_query($mysqli, $query);

    if (mysqli_num_rows($result)==1) {
        header("Location: welcome.php");
    } else {
        $msg = "Inccorect Password";
    }
}

?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="style.css">
<title> Music Website || Login</title>
</head>
 
</body>
    <header>
        <div class="left_bx1">
            <div class="content">
                <form action="#" method="POST">
    
                    <h3>Login</h3>
                    <div class="card">
                        <label for="name">Name</label>
                        <input type="text" name="user_name" placeholder="Enter Your Name" required>
                    </div>

                    <div class="card">
                        <label for="password">Password</label>
                        <input type="password" name="user_password" placeholder="Enter Password" required>
                    </div>
    
                    <input type="submit" value="Log in" class="submit">
                    <div class="check">
                        <input type="checkbox"><span>Remember Me</span>
                    </div>
                    <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
                </form>
            </div>
          </div>
          <div class="right_bx1">
            <img src="img/log1.jpg" alt="">
            <?php
            if ($msg) {
                echo ('<h3>'.$msg.'</h3>');
            }
            ?>
      
          </div>
    </header>


</body>
</html>