
<?php
$username = "root"; 
$password = ""; 
$database = "login"; 
$mysqli = new mysqli("localhost", $username, $password, $database); 
?>
